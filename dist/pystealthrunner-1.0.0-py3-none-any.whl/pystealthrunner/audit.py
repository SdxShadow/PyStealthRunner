import os, sys

def check_consent():
    pass
